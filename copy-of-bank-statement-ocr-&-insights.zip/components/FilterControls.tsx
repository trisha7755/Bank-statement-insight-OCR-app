
import React from 'react';
import { DateFilter } from '../types';
import { FilterIcon, XCircleIcon } from './icons';

interface FilterControlsProps {
  categories: string[];
  onCategoryChange: (category: string) => void;
  onDateChange: (dates: DateFilter) => void;
  onReset: () => void;
  currentCategory: string;
  currentDates: DateFilter;
}

const FilterControls: React.FC<FilterControlsProps> = ({
  categories,
  onCategoryChange,
  onDateChange,
  onReset,
  currentCategory,
  currentDates
}) => {
  return (
    <section aria-labelledby="filter-title" className="mb-8">
      <div className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
              <FilterIcon className="h-6 w-6 text-gray-500" />
              <h3 id="filter-title" className="text-lg font-semibold text-gray-900">Filter Transactions</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 w-full sm:w-auto">
            {/* Category Filter */}
            <div className="w-full">
              <label htmlFor="category-filter" className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <select
                id="category-filter"
                value={currentCategory}
                onChange={(e) => onCategoryChange(e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              >
                <option value="all">All Categories</option>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            {/* Start Date */}
            <div className="w-full">
              <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 mb-1">
                Start Date
              </label>
              <input
                type="date"
                id="start-date"
                value={currentDates.startDate || ''}
                onChange={(e) => onDateChange({ ...currentDates, startDate: e.target.value || null })}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            {/* End Date */}
            <div className="w-full">
              <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 mb-1">
                End Date
              </label>
              <input
                type="date"
                id="end-date"
                value={currentDates.endDate || ''}
                onChange={(e) => onDateChange({ ...currentDates, endDate: e.target.value || null })}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            {/* Reset Button */}
            <div className="w-full self-end">
                <button
                    onClick={onReset}
                    className="flex items-center justify-center gap-2 w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-semibold text-sm hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all"
                    aria-label="Reset filters"
                >
                    <XCircleIcon className="h-4 w-4" />
                    Reset
                </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FilterControls;
