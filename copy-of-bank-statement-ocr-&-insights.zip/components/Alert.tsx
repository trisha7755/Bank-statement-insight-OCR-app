
import React from 'react';
import { AlertTriangleIcon, XIcon } from './icons';

interface AlertProps {
  message: string;
  onClose: () => void;
}

const Alert: React.FC<AlertProps> = ({ message, onClose }) => {
  return (
    <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-lg relative mb-6" role="alert">
      <div className="flex items-center">
        <AlertTriangleIcon className="h-5 w-5 mr-2" />
        <div>
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{message}</span>
        </div>
      </div>
      <button 
        onClick={onClose}
        className="absolute top-0 bottom-0 right-0 px-4 py-3"
        aria-label="Close"
      >
        <XIcon className="h-5 w-5" />
      </button>
    </div>
  );
};

export default Alert;
