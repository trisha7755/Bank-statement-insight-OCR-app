
import React, { useState, useCallback } from 'react';
import type { Transaction } from '../types';
import { CopyIcon, CheckIcon } from './icons';

interface TransactionTableProps {
  transactions: Transaction[];
}

const TransactionTable: React.FC<TransactionTableProps> = ({ transactions }) => {
  const [copied, setCopied] = useState(false);

  const copyToCsv = useCallback(() => {
    const headers = ['Date', 'Description', 'Amount', 'Type', 'Category', 'Notes', 'Statement Source'];
    const csvRows = [
      headers.join(','),
      ...transactions.map(t => {
        const amount = t.type === 'expense' ? -Math.abs(t.amount) : Math.abs(t.amount);
        const description = `"${t.description.replace(/"/g, '""')}"`;
        const category = `"${t.category.replace(/"/g, '""')}"`;
        const notes = `"${(t.notes || '').replace(/"/g, '""')}"`;
        const sourceFile = `"${(t.sourceFile || '').replace(/"/g, '""')}"`;
        return [t.date, description, amount, t.type, category, notes, sourceFile].join(',');
      })
    ];
    
    navigator.clipboard.writeText(csvRows.join('\n')).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [transactions]);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-4 sm:p-6 flex justify-end">
        <button
          onClick={copyToCsv}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-semibold text-sm hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all"
        >
          {copied ? <CheckIcon className="h-4 w-4 text-green-600" /> : <CopyIcon className="h-4 w-4" />}
          {copied ? 'Copied!' : 'Copy to CSV'}
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-500">
          <thead className="text-xs text-gray-500 uppercase bg-gray-50 font-medium">
            <tr>
              <th scope="col" className="px-6 py-3">Date</th>
              <th scope="col" className="px-6 py-3">Description</th>
              <th scope="col" className="px-6 py-3">Statement Source</th>
              <th scope="col" className="px-6 py-3">Category</th>
              <th scope="col" className="px-6 py-3 text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index} className="bg-white border-b hover:bg-gray-50">
                <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{transaction.date}</td>
                <td className="px-6 py-4">{transaction.description}</td>
                <td className="px-6 py-4 text-gray-500 italic truncate max-w-xs">{transaction.sourceFile}</td>
                <td className="px-6 py-4">
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-700">
                    {transaction.category}
                  </span>
                </td>
                <td className={`px-6 py-4 text-right font-semibold whitespace-nowrap ${transaction.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {transaction.type === 'income' ? '+' : '-'}${Math.abs(transaction.amount).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {transactions.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <p>No transactions found.</p>
        </div>
      )}
    </div>
  );
};

export default TransactionTable;
