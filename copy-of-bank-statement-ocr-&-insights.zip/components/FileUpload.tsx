
import React, { useState, useCallback } from 'react';
import { UploadCloudIcon } from './icons';

interface FileUploadProps {
  onFilesUploaded: (files: File[]) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFilesUploaded }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFilesUploaded(Array.from(e.dataTransfer.files));
      e.dataTransfer.clearData();
    }
  }, [onFilesUploaded]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesUploaded(Array.from(e.target.files));
    }
  };

  const dragDropClasses = isDragging ? 'border-indigo-600 bg-indigo-50' : 'border-gray-300 bg-white';

  return (
    <div 
      className={`relative flex flex-col items-center justify-center w-full p-8 text-center border-2 border-dashed rounded-xl transition-colors duration-300 ${dragDropClasses}`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
    >
      <UploadCloudIcon className="w-16 h-16 text-gray-400 mb-4"/>
      <p className="text-xl font-semibold text-gray-700">Drop your bank statements here</p>
      <p className="text-gray-500 mb-4">or click to browse</p>
      <label htmlFor="file-upload" className="cursor-pointer px-6 py-2 bg-indigo-600 text-white rounded-lg font-semibold shadow-sm hover:bg-indigo-700 focus-within:outline-none focus-within:ring-2 focus-within:ring-indigo-500 focus-within:ring-offset-2 transition-colors">
        Select Files
      </label>
      <input 
        id="file-upload"
        type="file" 
        multiple 
        accept="application/pdf,image/*" 
        className="sr-only" 
        onChange={handleFileChange} 
      />
      <p className="text-xs text-gray-400 mt-4">Supports: PDF, PNG, JPG, WEBP</p>
    </div>
  );
};

export default FileUpload;
