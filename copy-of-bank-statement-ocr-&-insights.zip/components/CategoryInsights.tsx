
import React from 'react';
import { TrendingUpIcon, TrendingDownIcon } from './icons';

interface CategoryData {
  category: string;
  amount: number;
}

interface CategoryInsightsProps {
  topIncome: CategoryData[];
  topExpenses: CategoryData[];
}

const CategoryList: React.FC<{ title: string; data: CategoryData[]; icon: React.ReactNode; barColor: string; }> = ({ title, data, icon, barColor }) => {
  if (data.length === 0) {
    return (
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="flex items-center gap-3 mb-4">
          {icon}
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        </div>
        <p className="text-sm text-gray-500">No data available for this period.</p>
      </div>
    );
  }
  
  const maxAmount = Math.max(...data.map(d => d.amount), 0);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
      <div className="flex items-center gap-3 mb-4">
        {icon}
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
      </div>
      <ul className="space-y-4">
        {data.map(({ category, amount }) => (
          <li key={category}>
            <div className="flex justify-between items-center mb-1 text-sm">
              <span className="font-medium text-gray-600">{category}</span>
              <span className="font-semibold text-gray-800">${amount.toFixed(2)}</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2">
              <div 
                className={`${barColor} h-2 rounded-full`}
                style={{ width: maxAmount > 0 ? `${(amount / maxAmount) * 100}%` : '0%' }}
                role="progressbar"
                aria-valuenow={amount}
                aria-valuemin={0}
                aria-valuemax={maxAmount}
                aria-label={`${category} amount`}
              ></div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

const CategoryInsights: React.FC<CategoryInsightsProps> = ({ topIncome, topExpenses }) => {
  const hasData = topIncome.length > 0 || topExpenses.length > 0;

  if (!hasData) {
    return null;
  }
  
  return (
    <section aria-labelledby="insights-title" className="mb-8">
      <h2 id="insights-title" className="text-xl font-bold text-gray-900 mb-4">Category Insights</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <CategoryList 
          title="Top Income Sources" 
          data={topIncome} 
          icon={<TrendingUpIcon className="h-6 w-6 text-emerald-500" />}
          barColor="bg-emerald-500"
        />
        <CategoryList 
          title="Top Spending Categories" 
          data={topExpenses} 
          icon={<TrendingDownIcon className="h-6 w-6 text-rose-500" />}
          barColor="bg-rose-500"
        />
      </div>
    </section>
  );
};

export default CategoryInsights;
