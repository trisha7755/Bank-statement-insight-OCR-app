
import React from 'react';
import { LightbulbIcon } from './icons';

interface FinancialInsightsProps {
  insights: string[];
  isLoading: boolean;
}

const FinancialInsights: React.FC<FinancialInsightsProps> = ({ insights, isLoading }) => {
  if (isLoading) {
    return (
      <section aria-labelledby="insights-title" className="mb-8">
        <h2 id="insights-title" className="text-xl font-bold text-gray-900 mb-4">AI-Generated Insights</h2>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="space-y-3">
                <div className="h-3 bg-gray-200 rounded w-full"></div>
                <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
            </div>
        </div>
      </section>
    );
  }
  
  if (insights.length === 0) {
    return null;
  }
  
  return (
    <section aria-labelledby="insights-title" className="mb-8">
      <h2 id="insights-title" className="text-xl font-bold text-gray-900 mb-4">AI-Generated Insights</h2>
      <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-200">
        <ul className="space-y-3">
          {insights.map((insight, index) => (
            <li key={index} className="flex items-start gap-3">
              <LightbulbIcon className="h-5 w-5 text-indigo-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-indigo-900">{insight}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default FinancialInsights;
