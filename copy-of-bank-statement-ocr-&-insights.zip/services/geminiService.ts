
import { GoogleGenAI, Type } from "@google/genai";
import type { Transaction } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedData = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });

  return {
    inlineData: {
      data: base64EncodedData,
      mimeType: file.type,
    },
  };
};

const EXTRACTION_PROMPT = `
You are a highly accurate financial data extraction tool. Your task is to analyze the provided bank statement files (which could be images or PDFs) and extract every transaction meticulously from ALL provided files into a single combined list. For each transaction, you must identify:
1.  **Date**: The exact date of the transaction. Use YYYY-MM-DD format.
2.  **Description**: A clear and concise description of the transaction.
3.  **Amount**: The numerical value of the transaction. Positive for all values.
4.  **Type**: Classify the transaction as either 'income' or 'expense'.
5.  **Category**: Assign a relevant spending/income category (e.g., 'Salary', 'Groceries', 'Utilities', 'Transportation', 'Entertainment', 'Shopping', 'Healthcare', 'Transfers'). If a clear category cannot be determined, use 'Miscellaneous'.
6.  **Notes**: This field can be left as an empty string.
7.  **Source File**: The name of the file this transaction was extracted from. The file names are provided in the prompt.

Return the result as a single JSON array of transaction objects that strictly adheres to the provided schema. Do not include any introductory text, explanations, or markdown formatting around the JSON.
`;

const extractionResponseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        date: { type: Type.STRING, description: 'Transaction date (YYYY-MM-DD)' },
        description: { type: Type.STRING },
        amount: { type: Type.NUMBER },
        type: { type: Type.STRING, enum: ['income', 'expense'] },
        category: { type: Type.STRING },
        notes: { type: Type.STRING },
        sourceFile: { type: Type.STRING, description: 'The name of the source file for the transaction' },
      },
      required: ['date', 'description', 'amount', 'type', 'category', 'sourceFile'],
    },
};


export const analyzeStatements = async (files: File[]): Promise<Transaction[]> => {
  try {
    const parts: any[] = [
        { text: EXTRACTION_PROMPT }
    ];

    for (const file of files) {
        parts.push({ text: `--- START OF FILE: ${file.name} ---` });
        parts.push(await fileToGenerativePart(file));
        parts.push({ text: `--- END OF FILE: ${file.name} ---` });
    }
    
    const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: {
            parts: parts
        },
        config: {
            responseMimeType: 'application/json',
            responseSchema: extractionResponseSchema
        }
    });

    const text = response.text;
    if (!text) {
        throw new Error('API returned an empty response.');
    }
    
    const cleanedText = text.replace(/^```json\s*|```\s*$/g, '').trim();
    const transactions = JSON.parse(cleanedText);

    if (!Array.isArray(transactions)) {
        throw new Error('API did not return a valid JSON array.');
    }

    return transactions as Transaction[];

  } catch (error) {
    console.error('Error analyzing statements with Gemini:', error);
    throw new Error('Failed to analyze bank statements. The model may have returned an invalid format.');
  }
};


const INSIGHTS_PROMPT = `
You are a helpful financial assistant. Based on the following list of transactions, generate between 2 and 5 brief, actionable insights.
Focus on identifying spending patterns, potential savings, recurring subscriptions, or significant one-time events from the transaction descriptions and categories.
Keep each insight to a single, concise sentence.
Return the output as a JSON array of strings. Do not include any introductory text, explanations, or markdown formatting around the JSON.
`;

const insightsResponseSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.STRING,
    },
};

export const generateFinancialInsights = async (transactions: Transaction[]): Promise<string[]> => {
    if (transactions.length === 0) return [];
    
    try {
        const transactionData = JSON.stringify(transactions, null, 2);
        
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: {
                parts: [
                    { text: INSIGHTS_PROMPT },
                    { text: `Here is the transaction data:\n${transactionData}` },
                ]
            },
            config: {
                responseMimeType: 'application/json',
                responseSchema: insightsResponseSchema,
            }
        });

        const text = response.text;
        if (!text) {
            return [];
        }

        const cleanedText = text.replace(/^```json\s*|```\s*$/g, '').trim();
        const insights = JSON.parse(cleanedText);

        if (!Array.isArray(insights)) {
            return [];
        }

        return insights as string[];

    } catch (error) {
        console.error('Error generating financial insights with Gemini:', error);
        throw new Error('Failed to generate financial insights.');
    }
};
